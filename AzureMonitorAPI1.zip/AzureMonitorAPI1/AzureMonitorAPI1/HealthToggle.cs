﻿namespace AzureMonitorAPI1
{
    public class HealthToggleService
    {
        private bool health = true;
        public bool HealthToggler { get { return health; } set { health = value; } }
    }
}
