﻿using Microsoft.Extensions.Caching.Memory;

namespace AzureMonitorAPI1
{
    public class CacheManager<T>
    {
        private MemoryCache _cache = new MemoryCache(new MemoryCacheOptions());

        public MemoryCache Cache { get => _cache; }

        public T Add(string key, T itemToCache)
        {
            return Add(key, itemToCache, 1, 7);
        }

        public T Add(string key, T itemToCache, int daysSlidingExpiry, int daysAbsoluteExpiry)
        {
            if (!_cache.TryGetValue(key, out T cacheEntry))
            {
                cacheEntry = itemToCache;

                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    .SetSlidingExpiration(TimeSpan.FromDays(daysSlidingExpiry))
                    .SetAbsoluteExpiration(TimeSpan.FromDays(daysAbsoluteExpiry))
                ;

                _cache.Set(key, cacheEntry, cacheEntryOptions);
            }
            return cacheEntry;
        }

        public T AddForMinutes(string key, T itemToCache, int minsSlidingExpiry, int minsAbsoluteExpiry)
        {
            if (!_cache.TryGetValue(key, out T cacheEntry))
            {
                cacheEntry = itemToCache;

                var cacheEntryOptions = new MemoryCacheEntryOptions()
                        .SetSlidingExpiration(TimeSpan.FromMinutes(minsSlidingExpiry))
                        .SetAbsoluteExpiration(TimeSpan.FromMinutes(minsAbsoluteExpiry))
                    ;

                _cache.Set(key, cacheEntry, cacheEntryOptions);
            }
            return cacheEntry;
        }

        public async Task<T> GetOrCreateAsync(string key, Task<T> cacheEntryCreator) => await _cache.GetOrCreateAsync(key, async _ => await cacheEntryCreator);


        public T Fetch(string key)
        {
            _cache.TryGetValue(key, out T cachedItem);
            return cachedItem;
        }

        public void Remove(string key)
        {
            if (_cache.TryGetValue(key, out _))
            {
                _cache.Remove(key);
            }
        }
    }
}
