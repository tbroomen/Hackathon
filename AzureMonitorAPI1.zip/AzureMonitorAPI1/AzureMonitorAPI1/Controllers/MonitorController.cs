﻿using System.Diagnostics;
using System.Net.Http;
using Azure.Core;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Mvc;
using IHostApplicationLifetime = Microsoft.Extensions.Hosting.IHostApplicationLifetime;

namespace AzureMonitorAPI1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MonitorController : ControllerBase
    {
        ILogger<MonitorController> _logger;
        IHttpClientFactory _httpClientFactory;
        CacheManager<object> _cacheManager;
        IHostApplicationLifetime applicationLifetime;
        HealthToggleService _healthToggleService;

        public MonitorController(ILogger<MonitorController> logger, IHttpClientFactory httpClientFactory, CacheManager<object> cacheManager, IHostApplicationLifetime appLifetime, HealthToggleService health)
        {
            _httpClientFactory = httpClientFactory;
            _logger = logger;
            _cacheManager = cacheManager;
            applicationLifetime = appLifetime;
            _healthToggleService = health;
        }

        [HttpGet]
        [Route("createcpuload")]
        public async Task<ActionResult> CreateCPULoad([FromQuery] int time, [FromQuery] int cpuUsage, CancellationToken cancellationToken)
        {
            _logger.LogInformation("CreateCPULoad: Enter.");

            List<Thread> threads = new List<Thread>();
            for (int i = 0; i < Environment.ProcessorCount; i++)
            {
                Thread t = new Thread(new ParameterizedThreadStart(CPUKill));
                t.Start(cpuUsage);
                threads.Add(t);
            }

            Thread.Sleep(time);

            foreach (var t in threads)
            {
                t.Abort();
            }

            _logger.LogInformation("CreateCPULoad: Exit.");

            return await Task.FromResult(Ok());
        }

        [HttpGet]
        [Route("creatememoryload")]
        public async Task<ActionResult> CreateMemoryLoad([FromQuery] int memory)
        {
            _logger.LogInformation("CreateCPULoad: Enter.");

            byte[] wasted = new byte[1024 * 1024 * 1024 * memory];

            _cacheManager.Add(new Guid().ToString(), wasted, 60, 60);

            _logger.LogInformation("CreateCPULoad: Exit.");

            return await Task.FromResult(Ok());
        }

        [HttpGet]
        [Route("killapi")]
        public async Task<ActionResult> KillApplication()
        {
            _logger.LogInformation("KillApplication: Enter.");

            applicationLifetime.StopApplication();

            _logger.LogInformation("KillApplication: Exit.");

            return await Task.FromResult(Ok());
        }

        [HttpGet]
        [Route("getlotsofgets")]
        public async Task<ActionResult> GetLotsOfGets([FromQuery] int number,[FromQuery] string url)
        {
            _logger.LogInformation("GetLotsOfGets: Enter.");

            var httpClient = _httpClientFactory.CreateClient();

            for (int i = 0; i < number; i++)
            {
                var httpRequestMessage = new HttpRequestMessage(
                    HttpMethod.Get,
                    url);
                await httpClient.SendAsync(httpRequestMessage);
            }

            _logger.LogInformation("GetLotsOfGets: Exit.");

            return Ok();
        }

        [HttpGet]
        [Route("getok")]
        public async Task<ActionResult> GetRequestOk()
        {
            _logger.LogInformation("GetRequestOk: Enter.");

            var rand = new Random();

            int randomint = rand.Next(301);

            Thread.Sleep(randomint);
            _logger.LogInformation("GetRequestOk: You asked for everything to be ok, and it is.");

            _logger.LogInformation("GetRequestOk: Exit.");

            return await Task.FromResult(Ok());
        }

        [HttpGet]
        [Route("getdownstreamapi")]
        public async Task<ActionResult> GetDownstreamApi([FromQuery] string url)
        {
            _logger.LogInformation("GetOtherApi: Enter.");
            
            var httpClient = _httpClientFactory.CreateClient();

            var httpRequestMessage = new HttpRequestMessage(
                HttpMethod.Get,
                url);

            var val = await httpClient.SendAsync(httpRequestMessage);

            return await Task.FromResult(Ok(val.Content));
        }

        [HttpGet]
        [Route("getlongok")]
        public async Task<ActionResult> GetLongRequestOk()
        {
            _logger.LogInformation("GetRequestOk: Enter.");

            Thread.Sleep(5000);

            _logger.LogInformation("GetRequestOk: You asked for everything to be ok, and it is.");

            _logger.LogInformation("GetRequestOk: Exit.");

            return await Task.FromResult(Ok());
        }

        [HttpGet]
        [Route("postok")]
        public async Task<ActionResult> PostRequestOk([FromQuery] string postBody)
        {
            _logger.LogInformation("PostRequestOk: Enter.");

            var rand = new Random();

            int randomint = rand.Next(1001);

            Thread.Sleep(randomint);
            _logger.LogInformation("PostRequestOk : You asked for everything to be ok, and it is.");

            _logger.LogInformation("PostRequestOk: Exit.");

            return await Task.FromResult(Ok(postBody.ToUpper()));
        }

        [HttpGet]
        [Route("getgetexception")]
        public async Task<ActionResult> GetRequestException()
        {
            _logger.LogInformation("GetRequestException: Enter.");

            var rand = new Random();

            int randomint = rand.Next(1001);

            Thread.Sleep(randomint);

            randomint = rand.Next(6);

            try
            {
                RandomException(randomint);
            }
            catch (Exception ex)
            {
                _logger.LogError("GetRequestException: There was an error because you wanted one." + ex.Message);
                return await Task.FromResult(StatusCode(500));
            }

            _logger.LogInformation("GetRequestException: Exit.");

            return await Task.FromResult(Ok());
        }

        [HttpPost]
        [Route("postgetexception")]
        public async Task<ActionResult> PostRequestException()
        {
            _logger.LogInformation("PostRequestException: Enter.");

            var rand = new Random();

            int randomint = rand.Next(1001);

            Thread.Sleep(randomint);

            randomint = rand.Next(6);

            try
            {
                RandomException(randomint);
            }
            catch (Exception ex)
            {
                _logger.LogError("PostRequestException: There was an error because you wanted one." + ex.Message);
                return StatusCode(500);
            }

            _logger.LogInformation("PostRequestException: Exit.");

            return await Task.FromResult(Ok());
        }

        private object RandomException(int randomInt) => randomInt switch
        {
            1 => throw new InvalidOperationException("There was an InvalidOperationException exception."),
            2 => throw new ArgumentException("There was an ArgumentException exception."),
            3 => throw new NullReferenceException("There was an NullReferenceException exception."),
            4 => throw new StackOverflowException("There was an StackOverflowException exception."),
            _ => throw new OutOfMemoryException("There was an OutOfMemoryException exception.")
        };

        [HttpGet]
        [Route("get400")]
        public async Task<ActionResult> GetRequest400()
        {
            _logger.LogInformation("GetRequest400: Enter.");

            var rand = new Random();

            int randomint = rand.Next(6);

            _logger.LogInformation("GetRequest400: Exit.");

            return randomint switch {
                1 => BadRequest(),
                2 => Unauthorized(),
                3 => Conflict(),
                4 => new UnsupportedMediaTypeResult(),
                5 => new UnprocessableEntityResult(),
                _ => NotFound(),
            }; ;
        }

        [HttpGet]
        [Route("logerror")]
        public async Task<ActionResult> LogError()
        {
            _logger.LogError("LogError: You logged an Error.");

            return await Task.FromResult(Ok());
        }

        [HttpGet]
        [Route("logwarn")]
        public async Task<ActionResult> LogWarn()
        {
            _logger.LogWarning("LogWarn: You logged an Warning.");

            return await Task.FromResult(Ok());
        }

        [HttpGet]
        [Route("getkvsecret")]
        public async Task<ActionResult<string>> GetKVSecret([FromQuery] string secretName)
        {
            _logger.LogInformation("GetKVSecret: Enter.");

            var options = new SecretClientOptions()
            {
                Retry =
                    {
                        Delay = TimeSpan.FromSeconds(2),
                        MaxDelay = TimeSpan.FromSeconds(16),
                        MaxRetries = 5,
                        Mode = RetryMode.Exponential
                    }
            };

            var client = new SecretClient(
                new Uri(string.Format("KVURL")),
                new DefaultAzureCredential(),
                options);
            _logger.LogTrace("Exit: TAL.DirectAP.Aggregator.Application.GraphQl.ApiKeyManagement.GetSecretInternal.");

            var secret = await client.GetSecretAsync(secretName);

            _logger.LogInformation("GetKVSecret: Exit.");

            return await Task.FromResult(Ok(secret));
        }

        [HttpGet]
        [Route("uploadblobtosa")]
        public async Task<ActionResult<string>> UploadBlobToSA([FromBody] IFormFile file,[FromQuery] string connectionString)
        {
            _logger.LogInformation("UploadBlob: Enter.");

            var filePath = Path.GetTempFileName();

            using (var stream = System.IO.File.Create(filePath))
            {
                await file.CopyToAsync(stream);
            }

            var name = new Guid().ToString();

            BlobClient blobClient = new BlobClient(
                connectionString: connectionString,
                blobContainerName: "mycrmfilescontainer",
                blobName: new Guid().ToString());

            await blobClient.UploadAsync(filePath);

            _logger.LogInformation("UploadBlob: Exit.");

            return await Task.FromResult(Ok($"Uploaded Blob Name: {name}"));
        }

        [HttpGet]
        [Route("togglehealth")]
        public async Task<ActionResult> ToggleHealth()
        {
            _logger.LogInformation("ToggleHealth: Enter.");

            _healthToggleService.HealthToggler = !_healthToggleService.HealthToggler;

            _logger.LogInformation("ToggleHealth: Exit.");

            return await Task.FromResult(Ok(_healthToggleService.HealthToggler));
        }

        private static void CPUKill(object cpuUsage)
        {
            Parallel.For(0, 1, new Action<int>((int i) =>
            {
                Stopwatch watch = new Stopwatch();
                watch.Start();
                while (true)
                {
                    if (watch.ElapsedMilliseconds > (int)cpuUsage)
                    {
                        Thread.Sleep(100 - (int)cpuUsage);
                        watch.Reset();
                        watch.Start();
                    }
                }
            }));
        }
    }
}
