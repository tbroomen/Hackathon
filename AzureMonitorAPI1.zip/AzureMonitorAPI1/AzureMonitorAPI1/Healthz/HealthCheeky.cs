﻿using AzureMonitorAPI1;
using Microsoft.Extensions.Diagnostics.HealthChecks;

public class HealthCheeky : IHealthCheck
{
    private readonly HealthToggleService _healthToggleService;

    public HealthCheeky(HealthToggleService healthToggleService)
    {
        _healthToggleService = healthToggleService;
    }

    public Task<HealthCheckResult> CheckHealthAsync(
        HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        if (_healthToggleService.HealthToggler)
        {
            return Task.FromResult(
                HealthCheckResult.Healthy("A healthy result."));
        }

        return Task.FromResult(
            new HealthCheckResult(
                context.Registration.FailureStatus, "An unhealthy result."));
    }
}
